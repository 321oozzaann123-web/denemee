import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), 'moduller'))

try:
    from machine_info_module import run_machine_info_module
    from echo_test_module import run_echo_test_module
    from sntp_client_module import run_sntp_client_module
    from socket_tools_module import run_socket_tools_module
except ImportError as e:
    print("=" * 70)
    print(f"[HATA] Modül yüklenemedi: {e}")
    print("Lütfen 'moduller' klasöründe tüm modül dosyalarının (.py) mevcut olduğundan emin olun.")
    print("=" * 70)
    sys.exit(1)


def display_project_info():
    print("\n" + "=" * 70)
    print(" " * 15 + "CEN322 - AĞ DİYAGNOSTİK VE ARAÇ PAKETİ PROJESİ")
    print(" " * 25 + "-" * 38)
    print(" " * 20 + "Öğrenci: Ozan Dural")
    print(" " * 20 + "Numara: 2021556027")
    print("=" * 70)


def display_menu():
    
    print("\n" + "+" + "-" * 50 + "+")
    print("|" + " " * 15 + "ANA MODÜL SEÇİM EKRANI" + " " * 13 + "|")
    print("+" + "=" * 50 + "+")
    
    print("| [1] A. MAKİNE BİLGİLERİ Modülü" + " " * 19 + "|")
    print("| [2] B. ECHO TEST Modülü (TCP/UDP)" + " " * 16 + "|")
    print("| [3] C. SNTP ZAMAN İSTEMCİSİ Modülü" + " " * 15 + "|")
    print("| [4] D. SOKET AYARLARI & HATA YÖNETİMİ Modülü" + " " * 7 + "|")
    
    print("+" + "-" * 50 + "+")
    
    print("| [5] TÜM MODÜLLERİ ÇALIŞTIR (TESLİMAT ÇIKTISI)" + " " * 4 + "|")
    print("| [0] ÇIKIŞ" + " " * 40 + "|")
    
    print("+" + "=" * 50 + "+" + "\n")
    
    while True:
        try:
            choice = input("Seçiminizi giriniz (0-5) > ")
            choice = int(choice)
            if 0 <= choice <= 5:
                return choice
            else:
                print(">>> Hata: Lütfen 0 ile 5 arasında bir sayı girin.")
        except ValueError:
            print(">>> Hata: Geçersiz giriş! Lütfen bir sayı girin.")


def run_selected_module(choice):
    
    if choice == 1:
        print("\n" + "=" * 60)
        print("A. MAKİNE BİLGİLERİ MODÜLÜ BAŞLATILIYOR")
        print("=" * 60 + "\n")
        run_machine_info_module()
        print("\n" + "-" * 60)
        print("A. MAKİNE BİLGİLERİ MODÜLÜ TAMAMLANDI")
        print("-" * 60)
        
    elif choice == 2:
        print("\n" + "=" * 60)
        print("B. ECHO TEST MODÜLÜ BAŞLATILIYOR")
        print("=" * 60 + "\n")
        run_echo_test_module()
        print("\n" + "-" * 60)
        print("B. ECHO TEST MODÜLÜ TAMAMLANDI")
        print("-" * 60)
        
    elif choice == 3:
        print("\n" + "=" * 60)
        print("C. SNTP İSTEMCİSİ MODÜLÜ BAŞLATILIYOR")
        print("=" * 60 + "\n")
        run_sntp_client_module()
        print("\n" + "-" * 60)
        print("C. SNTP İSTEMCİSİ MODÜLÜ TAMAMLANDI")
        print("-" * 60)
        
    elif choice == 4:
        print("\n" + "=" * 60)
        print("D. SOKET AYARLARI VE HATA YÖNETİMİ MODÜLÜ BAŞLATILIYOR")
        print("=" * 60 + "\n")
        run_socket_tools_module()
        print("\n" + "-" * 60)
        print("D. SOKET AYARLARI VE HATA YÖNETİMİ MODÜLÜ TAMAMLANDI")
        print("-" * 60)

    elif choice == 5:
        
        print("\n" + "#" * 70)
        print(" " * 10 + "TÜM MODÜLLER (TESLİMAT FORMATI) BAŞLATILIYOR")
        print("#" * 70 + "\n")
        
        run_selected_module(1)
        run_selected_module(2)
        run_selected_module(3)
        run_selected_module(4)
        
        print("\n" + "#" * 70)
        print(" " * 10 + "TÜM MODÜLLER BAŞARIYLA ÇALIŞTIRILMIŞTIR. PROJE TAMAMLANDI.")
        print(" " * 10 + "Bu çıktıyı raporunuza ekleyebilirsiniz.")
        print("#" * 70)
        sys.exit(0) 


def main():
    display_project_info()
    
    while True:
        choice = display_menu()
        
        if choice == 0:
            print("\nProje sonlandırılıyor. İyi çalışmalar.")
            break
        
        run_selected_module(choice)


if __name__ == "__main__":
    main()