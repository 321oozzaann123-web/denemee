import socket
import os
import platform
import netifaces as ni
import sys

def get_machine_info():
    """
    Yerel makinenin temel ağ ve sistem bilgilerini alır ve ekrana basar.
    """
    print("--- Temel Sistem ve Ağ Bilgileri ---")
    
    # 1. Host Adı ve IP Adresi
    try:
        host_name = socket.gethostname()
        ip_address = socket.gethostbyname(host_name)
        print(f"   [Hostname]: {host_name}")
        print(f"   [IP Adresi]: {ip_address}")
    except Exception as e:
        print(f"   [HATA] Hostname veya IP alınamadı: {e}")
    
    # 2. İşletim Sistemi ve Mimari
    print(f"   [İşletim Sistemi]: {platform.system()} {platform.release()}")
    print(f"   [Mimari]: {platform.machine()}")
    
    # 3. Ağ Arayüzleri
    print("\n--- Ağ Arayüzleri (Interface) ---")
    try:
        # netifaces kütüphanesi ile tüm arayüzleri listeleme
        interfaces = ni.interfaces()
        for iface in interfaces:
            print(f"   [Arayüz Adı]: {iface}")
            # Arayüze ait adresleri al
            addrs = ni.ifaddresses(iface)
            
            # IPv4 adresini kontrol et
            if ni.AF_INET in addrs:
                ipv4_info = addrs[ni.AF_INET][0]
                print(f"      [IPv4 Adresi]: {ipv4_info.get('addr', 'Yok')}")
                print(f"      [Netmask]: {ipv4_info.get('netmask', 'Yok')}")
            
            # MAC adresini (Link Katmanı) kontrol et
            if ni.AF_LINK in addrs:
                mac_info = addrs[ni.AF_LINK][0]
                print(f"      [MAC Adresi]: {mac_info.get('addr', 'Yok')}")
    
    except ImportError:
        print("   [UYARI] netifaces kütüphanesi yüklü değil. Arayüz bilgileri sınırlı olabilir.")
    except Exception as e:
        print(f"   [HATA] Ağ arayüzleri okunurken hata oluştu: {e}")


def run_machine_info_module():
    """
    Modül A: Makine Bilgileri Modülünün ana çalıştırma fonksiyonu.
    """
    print("="*60)
    print("A. MAKİNE BİLGİLERİ MODÜLÜ BAŞLATILIYOR")
    print("="*60)
    
    get_machine_info()
    
    print("="*60)
    print("A. MAKİNE BİLGİLERİ MODÜLÜ TAMAMLANDI")
    print("="*60)
    print("\n")


# Sadece bu dosya doğrudan çalıştırılırsa, testi yap.
if __name__ == "__main__":
    run_machine_info_module()