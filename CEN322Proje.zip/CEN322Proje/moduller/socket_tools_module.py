import socket
import sys
import argparse

# Tampon büyüklükleri için sabitler
SEND_BUF_SIZE = 4096
RECV_BUF_SIZE = 2048

def set_and_get_socket_options():
    """
    Soket oluşturur, temel ayarları (timeout, buffer büyüklükleri, SO_REUSEADDR) 
    gösterir ve değiştirir.
    """
    print("--- Soket Ayarları Kontrolü ---")
    
    try:
        # Yeni bir TCP soketi oluştur
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        # 1. Soket Zaman Aşımı (Timeout) Kontrolü
        print(f"   [Varsayılan] Soket Zaman Aşımı: {sock.gettimeout()} saniye")
        
        # Zaman aşımını 10 saniyeye ayarla
        sock.settimeout(10)
        print(f"   [Ayarlanan] Soket Zaman Aşımı: {sock.gettimeout()} saniye")

        # 2. Gönderme (Send) Tampon Boyutu Kontrolü
        sndbufsize_before = sock.getsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF)
        print(f"   [Varsayılan] Gönderme Tampon Boyutu (SO_SNDBUF): {sndbufsize_before} byte")
        
        # Gönderme tampon boyutunu değiştir
        # Not: İşletim sistemi bu değeri yuvarlayabilir veya reddedebilir.
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SEND_BUF_SIZE)
        sndbufsize_after = sock.getsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF)
        print(f"   [Ayarlanan] Gönderme Tampon Boyutu (SO_SNDBUF): {sndbufsize_after} byte")

        # 3. Alma (Receive) Tampon Boyutu Kontrolü
        rcvbufsize_before = sock.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
        print(f"   [Varsayılan] Alma Tampon Boyutu (SO_RCVBUF): {rcvbufsize_before} byte")
        
        # Alma tampon boyutunu değiştir
        # Not: İşletim sistemi bu değeri yuvarlayabilir veya reddedebilir.
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, RECV_BUF_SIZE)
        rcvbufsize_after = sock.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
        print(f"   [Ayarlanan] Alma Tampon Boyutu (SO_RCVBUF): {rcvbufsize_after} byte")

        # 4. Adres Yeniden Kullanımı (SO_REUSEADDR) Kontrolü
        reuse_before = sock.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR)
        print(f"   [Varsayılan] Adres Yeniden Kullanımı (SO_REUSEADDR): {reuse_before}")

        # Adres yeniden kullanımını etkinleştir (Genellikle 0 veya 1 döner)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        reuse_after = sock.getsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR)
        print(f"   [Ayarlanan] Adres Yeniden Kullanımı (SO_REUSEADDR): {reuse_after} (Etkin)")
        
        # Soketi kapat
        sock.close()

    except Exception as e:
        print(f"   [HATA] Soket Ayarları sırasında bir sorun oluştu: {e}")
        sys.exit(1)

def run_socket_tools_module():
    """
    Modül D: Soket Ayarları ve Hata Yönetimi Modülünün ana çalıştırma fonksiyonu.
    """
    print("="*60)
    print("D. SOKET AYARLARI VE HATA YÖNETİMİ MODÜLÜ BAŞLATILIYOR")
    print("="*60)
    
    set_and_get_socket_options()
    
    print("="*60)
    print("D. SOKET AYARLARI VE HATA YÖNETİMİ MODÜLÜ TAMAMLANDI")
    print("="*60)
    print("\n")

# Sadece bu dosya doğrudan çalıştırılırsa, testi yap.
if __name__ == "__main__":
    run_socket_tools_module()