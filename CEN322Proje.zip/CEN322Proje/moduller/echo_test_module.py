import socket
import sys
import time

# Host ve Port ayarları (Test için kullanılacak varsayılan Echo sunucusu adresi)
# NOT: Gerçek bir Echo sunucusu çalışmıyorsa bu client bağlantı hatası verecektir.
# Bu hata (Connection Refused), modülün hata yönetimini test ettiğini gösterir.
ECHO_SERVER_HOST = 'localhost' 
ECHO_SERVER_PORT = 9999
TEST_MESSAGE = "CEN322 Echo Test Mesaji"

def echo_client_test(host, port, message):
    """
    Basit bir TCP istemcisi oluşturur ve bir yankı sunucusuna bağlanmayı dener.
    """
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = (host, port)
    
    print(f"   -> Sunucuya bağlanmaya çalışılıyor: {host}:{port}")
    
    try:
        # Zaman aşımını ayarla (3 saniye)
        sock.settimeout(3) 
        sock.connect(server_address)
        
        # Bağlantı başarılı ise devam et
        print(f"   -> Bağlantı başarılı. Gönderilen veri: '{message}'")
        sock.sendall(message.encode('utf-8'))
        
        # Yanıtı bekle
        data = sock.recv(1024)
        
        if data:
            received_message = data.decode('utf-8')
            # Yanıtı temizleyip göster
            print(f"   <- Sunucudan Gelen Yanıt (ECHO): '{received_message.strip()}'")
            return "BAŞARILI: Yanıt alındı."
        else:
            return "UYARI: Bağlantı kuruldu ancak yanıt gelmedi."

    except socket.timeout:
        return "HATA: Bağlantı zaman aşımına uğradı. Sunucu kapalı veya çok yavaş."
    except ConnectionRefusedError:
         return f"HATA: Bağlantı reddedildi. {host}:{port} adresinde bir sunucu çalışmıyor."
    except socket.error as e:
        return f"HATA: Bağlantı hatası ({e})."
    except Exception as e:
        return f"HATA: Beklenmedik bir hata oluştu: {e}"
        
    finally:
        # Soketi kapat
        sock.close()
        
def run_echo_test_module():
    """
    Modül B: Echo Test Modülünün ana çalıştırma fonksiyonu.
    """
    print("="*60)
    print("B. ECHO TEST MODÜLÜ BAŞLATILIYOR")
    print("="*60)
    
    print("--- Basit Echo (Yankı) İstemci Testi ---")
    
    # Testi çalıştır
    result = echo_client_test(ECHO_SERVER_HOST, ECHO_SERVER_PORT, TEST_MESSAGE)
    
    # Sonucu ekrana yazdır
    print(f"   [SONUÇ]: {result}")
    
    print("="*60)
    print("B. ECHO TEST MODÜLÜ TAMAMLANDI")
    print("="*60)
    print("\n")

if __name__ == "__main__":
    run_echo_test_module()