import ntplib
from time import ctime
import socket
import sys

# Dünya çapındaki NTP sunucularının havuzu
NTP_SERVER = 'pool.ntp.org' 

def sntp_get_time():
    """
    SNTP (Simple Network Time Protocol) istemcisi fonksiyonu.
    ntplib kütüphanesini kullanarak NTP sunucusundan doğru saati alır.
    """
    print(f"--- SNTP Zaman İstemcisi Testi ({NTP_SERVER}) ---")
    ntp_client = ntplib.NTPClient()
    
    try:
        # Zaman sunucusuna istek gönder (5 saniye zaman aşımı ile)
        response = ntp_client.request(NTP_SERVER, timeout=5) 
        
        # Alınan zamanı okunabilir formata çevir
        current_time = ctime(response.tx_time)
        
        print(f"   - Sunucudan Alınan Zaman: {current_time}")
        print(f"   - Gecikme (Gidiş-Dönüş Süresi): {response.delay:.4f} saniye")
        print(f"   - Hassasiyet (Offset: Yerel saatten fark): {response.offset:.4f} saniye")
        
    except ntplib.NTPException:
        print(f"   [HATA]: {NTP_SERVER} sunucusundan zaman alınamadı. Güvenlik duvarınızı veya ağ bağlantınızı kontrol edin.")
        
    except socket.gaierror:
        print(f"   [HATA]: DNS Hatası. '{NTP_SERVER}' adresi çözümlenemedi.")
        
    except Exception as e:
        print(f"   [HATA]: Beklenmeyen bir hata oluştu: {e}")

def run_sntp_client_module():
    """
    Modül C: SNTP İstemcisi Modülünün ana çalıştırma fonksiyonu.
    """
    print("="*60)
    print("C. SNTP İSTEMCİSİ MODÜLÜ BAŞLATILIYOR")
    print("="*60)
    
    sntp_get_time()
    
    print("="*60)
    print("C. SNTP İSTEMCİSİ MODÜLÜ TAMAMLANDI")
    print("="*60)
    print("\n")

# Sadece bu dosya doğrudan çalıştırılırsa, testi yap.
if __name__ == "__main__":
    run_sntp_client_module()